import re
import pytest
from playwright.sync_api import Page, expect

BASE_URL = "http://195.19.209.79"

def extract_title_from_card(card_text: str) -> str:
    lines = [line.strip() for line in card_text.split('\n') if line.strip()]
    price_idx = next((i for i, line in enumerate(lines) if '₽' in line), None)
    if price_idx is None:
        return lines[0] if lines else ""
    title_idx = price_idx - 1
    while title_idx >= 0 and (
        lines[title_idx] in ["Фото", "Электроника", "Недвижимость", "Транспорт"]
        or lines[title_idx].lower() == "требует доработок"
    ):
        title_idx -= 1
    if title_idx < 0:
        return ""
    return lines[title_idx]

class TestAdsDesktop:
    def test_search_by_title(self, page: Page):
        print("\n[Тест] Поиск по заголовку, части заголовка, числу, дефису и несуществующему символу")
        page.goto(f"{BASE_URL}/ads")
        page.wait_for_selector(".ads-page__title")
        page.wait_for_timeout(1000)

        cards = page.locator(".ads-page__grid > div")
        initial_count = cards.count()
        first_title = extract_title_from_card(cards.first.inner_text())
        search_input = page.get_by_placeholder("Найти объявление...")

        print(f"[Шаг 1] Исходное название: '{first_title}'")
        print(f"[Шаг 2] Исходное количество: {initial_count}")

        print("[Шаг 3] Тест по полному названию:")
        search_input.click()
        search_input.press_sequentially(first_title, delay=50)
        search_input.press("Enter")
        page.wait_for_timeout(1500)
        assert search_input.input_value() == first_title
        filtered_count = page.locator(".ads-page__grid > div").count()
        print(f"  Найдено: {filtered_count}")
        assert filtered_count > 0
        assert filtered_count < initial_count
        for i in range(filtered_count):
            assert first_title.lower() in page.locator(".ads-page__grid > div").nth(i).inner_text().lower()
        search_input.clear()
        search_input.press("Enter")
        page.wait_for_timeout(500)

        print("[Шаг 4] Тест по части названия:")
        partial_title = first_title[:4]
        search_input.click()
        search_input.press_sequentially(partial_title, delay=50)
        search_input.press("Enter")
        page.wait_for_timeout(1500)
        filtered_count = page.locator(".ads-page__grid > div").count()
        print(f"  Найдено: {filtered_count}")
        assert filtered_count > 0
        for i in range(filtered_count):
            assert partial_title.lower() in page.locator(".ads-page__grid > div").nth(i).inner_text().lower()
        search_input.clear()
        search_input.press("Enter")
        page.wait_for_timeout(500)

        print("[Шаг 5] Тест по числу:")
        price_line = next((l for l in cards.first.inner_text().split('\n') if '₽' in l), "100 ₽")
        number_query = re.sub(r'\D', '', price_line) or "100"
        search_input.click()
        search_input.press_sequentially(number_query, delay=50)
        search_input.press("Enter")
        page.wait_for_timeout(1500)
        filtered_count = page.locator(".ads-page__grid > div").count()
        print(f"  Найдено: {filtered_count}")
        assert filtered_count > 0
        search_input.clear()
        search_input.press("Enter")
        page.wait_for_timeout(500)

        print("[Шаг 6] Тест по дефису (символ '-'):")
        search_input.click()
        search_input.press_sequentially("-", delay=50)
        search_input.press("Enter")
        page.wait_for_timeout(1500)
        filtered_count = page.locator(".ads-page__grid > div").count()
        print(f"  Найдено: {filtered_count}")
        assert filtered_count > 0
        search_input.clear()
        search_input.press("Enter")
        page.wait_for_timeout(500)

        print("[Шаг 7] Тест по несуществующему символу (^):")
        search_input.click()
        search_input.press_sequentially("^", delay=50)
        search_input.press("Enter")
        page.wait_for_timeout(1500)
        filtered_count = page.locator(".ads-page__grid > div").count()
        print(f"  Найдено: {filtered_count}")
        assert filtered_count == 0
        search_input.clear()
        search_input.press("Enter")

        print("[Шаг 8] Поиск сброшен. Тест пройден!\n")

    def test_sort_by_date_and_name(self, page: Page):
        print("\n[Тест] Сортировка по дате (старые/новые) и по названию (А→Я, Я→А)")
        page.goto(f"{BASE_URL}/ads")
        page.wait_for_selector(".ads-page__title")
        page.wait_for_timeout(500)
        sort_dropdown = page.locator(".ads-page__sort-select")

        print("[Шаг 1] Сортировка по новизне (сначала старые)")
        sort_dropdown.click()
        sort_option = page.get_by_text("По новизне (сначала старые)", exact=True).last
        expect(sort_option).to_be_visible()
        sort_option.click()
        page.wait_for_timeout(500)
        expect(page.locator(".ads-page__sort-select")).to_contain_text("По новизне (сначала старые)")
        cards_old = page.locator(".ads-page__grid > div")
        titles_old = [cards_old.nth(i).inner_text() for i in range(cards_old.count())]
        print(f"  Запомнено {len(titles_old)} карточек")

        print("[Шаг 2] Сортировка по новизне (сначала новые)")
        sort_dropdown.click()
        sort_option = page.get_by_text("По новизне (сначала новые)", exact=True).last
        expect(sort_option).to_be_visible()
        sort_option.click()
        page.wait_for_timeout(500)
        expect(page.locator(".ads-page__sort-select")).to_contain_text("По новизне (сначала новые)")
        cards_new = page.locator(".ads-page__grid > div")
        titles_new = [cards_new.nth(i).inner_text() for i in range(cards_new.count())]
        assert titles_new != titles_old, "Сортировка по дате не меняет порядок карточек!"
        print("  Порядок карточек изменился, сортировка по дате работает")

        print("[Шаг 3] Сортировка по названию (А → Я)")
        sort_dropdown.click()
        sort_option = page.get_by_text("По названию (А → Я)", exact=True).last
        expect(sort_option).to_be_visible()
        sort_option.click()
        page.wait_for_timeout(500)
        expect(page.locator(".ads-page__sort-select")).to_contain_text("По названию (А → Я)")
        cards = page.locator(".ads-page__grid > div")
        titles = []
        for i in range(cards.count()):
            titles.append(extract_title_from_card(cards.nth(i).inner_text()).lower())
        assert titles == sorted(titles), f"Сортировка по названию (А-Я) не работает. Получено: {titles}"
        print("  Сортировка А→Я корректна")

        print("[Шаг 4] Сортировка по названию (Я → А)")
        sort_dropdown.click()
        sort_option = page.get_by_text("По названию (Я → А)", exact=True).last
        expect(sort_option).to_be_visible()
        sort_option.click()
        page.wait_for_timeout(500)
        expect(page.locator(".ads-page__sort-select")).to_contain_text("По названию (Я → А)")
        cards = page.locator(".ads-page__grid > div")
        titles = []
        for i in range(cards.count()):
            titles.append(extract_title_from_card(cards.nth(i).inner_text()).lower())
        assert titles == sorted(titles, reverse=True), f"Сортировка по названию (Я-А) не работает. Получено: {titles}"
        print("  Сортировка Я→А корректна")

        sort_dropdown.click()
        sort_option = page.get_by_text("По новизне (сначала новые)", exact=True).last
        sort_option.click()
        page.wait_for_timeout(500)
        print("[Шаг 5] Сортировка восстановлена. Тест пройден!\n")

    def test_filters_and_reset(self, page: Page):
        print("\n[Тест] Переключатель 'Требует доработок' и сброс фильтров")
        page.goto(f"{BASE_URL}/ads")
        page.wait_for_selector(".ads-page__title")

        revision_toggle = page.locator(".ant-switch")
        print("[Шаг 1] Включаем фильтр 'Требует доработок'")
        revision_toggle.click()
        page.wait_for_timeout(500)
        assert "ant-switch-checked" in (revision_toggle.get_attribute("class") or "")
        print("  Фильтр включён")

        reset_btn = page.get_by_role("button", name="Сбросить фильтры")
        print("[Шаг 2] Нажимаем 'Сбросить фильтры'")
        reset_btn.click()
        page.wait_for_timeout(500)

        expect(revision_toggle).not_to_have_class("ant-switch-checked")
        print("  Фильтр сброшен, переключатель выключен")
        print("[Шаг 3] Тест пройден!\n")

    def test_category_filters(self, page: Page):
        print("\n[Тест] Фильтрация по категориям (по одной, комбинации, сброс)")
        page.goto(f"{BASE_URL}/ads")
        page.wait_for_selector(".ads-page__title")
        page.wait_for_timeout(1000)

        cards = page.locator(".ads-page__grid > div")
        initial_count = cards.count()
        print(f"[Шаг 0] Исходное количество объявлений: {initial_count}")

        categories = ["Транспорт", "Недвижимость", "Электроника"]

        def get_checkbox(name):
            return page.get_by_role("checkbox", name=name)

        def all_cards_contain_any(category_list):
            count = page.locator(".ads-page__grid > div").count()
            if count == 0:
                return True
            for i in range(count):
                card = page.locator(".ads-page__grid > div").nth(i)
                cat_elem = card.locator(".ad-card__category")
                if cat_elem.count() > 0:
                    card_cat = cat_elem.inner_text()
                else:
                    card_cat = card.inner_text()
                if not any(cat in card_cat for cat in category_list):
                    return False
            return True

        print("[Шаг 1] Проверка каждой категории отдельно:")
        for cat in categories:
            print(f"  Включаем категорию '{cat}'")
            checkbox = get_checkbox(cat)
            checkbox.click()
            page.wait_for_timeout(500)
            filtered_count = page.locator(".ads-page__grid > div").count()
            print(f"    Найдено объявлений: {filtered_count}")
            assert all_cards_contain_any([cat]), f"Не все карточки содержат категорию '{cat}'"
            checkbox.click()
            page.wait_for_timeout(500)

        print("[Шаг 2] Проверка комбинации первых двух категорий (Транспорт и Недвижимость):")
        for cat in categories[:2]:
            get_checkbox(cat).click()
        page.wait_for_timeout(500)
        filtered_count = page.locator(".ads-page__grid > div").count()
        print(f"  Найдено объявлений: {filtered_count}")
        assert all_cards_contain_any(categories[:2]), "Не все карточки содержат Транспорт или Недвижимость"
        for cat in categories[:2]:
            get_checkbox(cat).click()
        page.wait_for_timeout(500)

        print("[Шаг 3] Проверка всех трёх категорий одновременно:")
        for cat in categories:
            get_checkbox(cat).click()
        page.wait_for_timeout(500)
        filtered_count = page.locator(".ads-page__grid > div").count()
        print(f"  Найдено объявлений: {filtered_count}")
        assert all_cards_contain_any(categories), "Не все карточки содержат одну из трёх категорий"

        print("[Шаг 4] Сброс фильтров и проверка восстановления:")
        reset_btn = page.get_by_role("button", name="Сбросить фильтры")
        reset_btn.click()
        page.wait_for_timeout(500)
        for cat in categories:
            expect(get_checkbox(cat)).not_to_be_checked()
        final_count = page.locator(".ads-page__grid > div").count()
        print(f"  После сброса количество: {final_count}")
        assert final_count == initial_count, "Количество после сброса не совпадает с исходным"
        print("[Шаг 5] Тест пройден!\n")

    def test_pagination_and_ad_navigation(self, page: Page):
        print("\n[Тест] Пагинация и переход на страницу объявления")
        page.goto(f"{BASE_URL}/ads")
        page.wait_for_selector(".ads-page__title")
        page.wait_for_timeout(500)

        print("[Шаг 1] Переходим на страницу 2")
        page.locator(".ads-page__pagination").get_by_text("2").first.click()
        page.wait_for_timeout(1000)
        print(f"  Текущий URL: {page.url}")

        first_card = page.locator(".ads-page__grid > div").first
        print("[Шаг 2] Кликаем по первому объявлению")
        first_card.click(force=True)

        page.wait_for_url(re.compile(r'/ads/\d+'))
        assert re.search(r'/ads/\d+', page.url)
        print(f"  Открыто объявление: {page.url}")
        print("[Шаг 3] Тест пройден!\n")

    def test_edit_validation_save_cancel(self, page: Page):
        print("\n[Тест] Редактирование: валидация, сохранение, отмена и восстановление исходной цены")
        page.goto(f"{BASE_URL}/ads")
        page.wait_for_selector(".ads-page__title")
        page.wait_for_timeout(1500)

        first_card = page.locator(".ads-page__grid > div").first
        print("[Шаг 1] Открываем первое объявление")
        first_card.click()
        page.wait_for_url(re.compile(r'/ads/\d+'))
        ad_id = re.search(r'/ads/(\d+)', page.url).group(1)
        print(f"  ID объявления: {ad_id}")

        page.goto(f"{BASE_URL}/ads/{ad_id}/edit")
        price_input = page.locator(".edit-form .ant-input-number-input")
        original_price = price_input.input_value()
        print(f"  Исходная цена: '{original_price}'")

        print("[Шаг 2] Проверяем валидацию: очищаем поле цены и пытаемся сохранить")
        price_input.fill("")
        page.get_by_role("button", name="Сохранить").click()
        expect(page.locator(".ant-form-item-explain-error")).to_be_visible(timeout=3000)
        print("  Ошибка валидации появилась")

        print("[Шаг 3] Вводим цену 1 и сохраняем")
        price_input.fill("1")
        page.get_by_role("button", name="Сохранить").click()
        page.wait_for_url(re.compile(r'/ads/\d+'))
        print(f"  Сохранено, URL: {page.url}")

        print("[Шаг 4] Проверяем отмену редактирования")
        page.goto(f"{BASE_URL}/ads/{ad_id}/edit")
        page.get_by_role("button", name="Отменить").click()
        page.get_by_role("button", name="OK").click()
        page.wait_for_url(re.compile(r'/ads/\d+'))
        print(f"  Отменено, возврат на страницу объявления: {page.url}")

        print("[Шаг 5] Восстанавливаем исходную цену")
        page.goto(f"{BASE_URL}/ads/{ad_id}/edit")
        price_input = page.locator(".edit-form .ant-input-number-input")
        restore_value = original_price if original_price.strip() else "1"
        price_input.fill(restore_value)
        page.get_by_role("button", name="Сохранить").click()
        page.wait_for_url(re.compile(r'/ads/\d+'))
        print(f"  Цена восстановлена до '{restore_value}'")

        print("[Шаг 6] Тест пройден!\n")

    def test_ai_tools(self, page: Page):
        print("\n[Тест] AI-инструменты: определение цены и генерация описания")
        page.goto(f"{BASE_URL}/ads")
        page.wait_for_selector(".ads-page__title")
        page.wait_for_timeout(1500)

        first_card = page.locator(".ads-page__grid > div").first
        print("[Шаг 1] Открываем первое объявление")
        first_card.click()
        page.wait_for_url(re.compile(r'/ads/\d+'))
        ad_id = re.search(r'/ads/(\d+)', page.url).group(1)
        print(f"  ID объявления: {ad_id}")
        page.goto(f"{BASE_URL}/ads/{ad_id}/edit")

        print("[Шаг 2] Проверяем кнопку 'Узнать цену'")
        price_btn = page.get_by_role("button", name="Узнать цену")
        expect(price_btn).to_be_visible()
        price_btn.click()
        expect(page.get_by_role("button", name="Применить").first).to_be_visible(timeout=10000)
        print("  Диалог с ценой открыт, кнопка 'Применить' видна")
        page.get_by_role("button", name="Закрыть").click()

        print("[Шаг 3] Проверяем кнопку генерации/улучшения описания")
        desc_btn = page.get_by_role("button", name=re.compile(r"(Придумать|Улучшить) описание"))
        expect(desc_btn).to_be_visible()
        desc_btn.click()
        expect(page.get_by_text("Ответ AI:")).to_be_visible(timeout=10000)
        print("  Ответ AI получен")
        print("[Шаг 4] Тест пройден!\n")


class TestAdsMobile:
    def test_theme_switch(self, page: Page):
        print("\n[Тест] Переключение темы (светлая/тёмная) на мобильном устройстве")
        page.set_viewport_size({"width": 375, "height": 812})
        page.goto(f"{BASE_URL}/ads")
        page.wait_for_selector(".ads-page__title")

        theme_toggle = page.locator(".app-header__theme")
        expect(theme_toggle).to_be_visible()
        print("[Шаг 1] Кнопка переключения темы видна")

        app_div = page.locator(".app")
        old_class = app_div.get_attribute("class") or ""
        print(f"  Текущий класс приложения: {old_class}")

        print("[Шаг 2] Кликаем по переключателю темы")
        theme_toggle.click()
        page.wait_for_timeout(500)
        new_class = app_div.get_attribute("class") or ""

        assert "dark" in new_class, f"Класс темы не сменился. Старый: {old_class}, Новый: {new_class}"
        print(f"  Новый класс приложения: {new_class} (тема тёмная)")

        print("[Шаг 3] Возвращаем тему обратно")
        theme_toggle.click()
        print("[Шаг 4] Тест пройден!\n")
